#ifndef MINGW_PATHS_H
#define MINGW_PATHS_H

#define _PATH_DEV "/dev/"

#endif