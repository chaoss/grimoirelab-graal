#include <stdbool.h>
#include <string.h>

bool starts_with(const char*, const char*);