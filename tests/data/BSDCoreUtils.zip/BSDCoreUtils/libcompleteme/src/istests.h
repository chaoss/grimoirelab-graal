#include <windows.h>
#include <stdbool.h>


bool has_win_sufix(const char*, int);
bool has_exe_suffix(const char*);
bool has_exec_format(const char*);