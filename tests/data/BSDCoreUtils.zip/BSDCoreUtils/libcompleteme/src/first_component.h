#include "linked_strings.h"

struct list *get_comp_of_path(const char*);