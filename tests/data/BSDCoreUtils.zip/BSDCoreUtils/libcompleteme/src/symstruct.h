typedef struct { char *key; int val; } t_symstruct;
