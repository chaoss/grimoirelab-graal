#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool is_prefixed_with(const char*, const char*);