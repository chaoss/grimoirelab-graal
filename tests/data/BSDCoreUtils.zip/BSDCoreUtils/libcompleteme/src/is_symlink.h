#include <windows.h>

int is_symlink(DWORD, const char*, WIN32_FIND_DATAA*);