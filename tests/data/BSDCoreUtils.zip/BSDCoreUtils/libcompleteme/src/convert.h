#include <windows.h>
#include "compat.h"

mode_t file_attr_to_st_mode(DWORD);