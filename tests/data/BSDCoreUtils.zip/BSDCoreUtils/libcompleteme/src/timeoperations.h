#include <windows.h>
#include "compat.h"


struct timespec filetime_to_timespec(const FILETIME*);