/*	$OpenBSD: true.c,v 1.1 2015/11/11 19:05:28 deraadt Exp $	*/

/* Public domain - Theo de Raadt */

int
main(int argc, char *argv[])
{
	return (0);
}
